<?php
$mensagem = '';
$bloco_ipv6 = '';

// Função para executar comando shell
function execCommand($cmd) {
    $output = shell_exec("$cmd 2>&1");
    return $output;
}

// Habilitar IPv6 no sistema
function enableIPv6() {
    execCommand("sysctl -w net.ipv6.conf.all.disable_ipv6=0");
    execCommand("sysctl -w net.ipv6.conf.default.disable_ipv6=0");
    execCommand('echo "net.ipv6.conf.all.disable_ipv6 = 0" >> /etc/sysctl.conf');
    execCommand('echo "net.ipv6.conf.default.disable_ipv6 = 0" >> /etc/sysctl.conf');
    execCommand("sysctl -p");
}

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ipv6'])) {
    $bloco = trim($_POST['ipv6']);
    
    // Validação básica do formato IPv6
    if (filter_var($bloco . '1', FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        // Habilitar IPv6 antes de salvar
        enableIPv6();
        if (file_put_contents('/var/www/html/block_ipv6.txt', $bloco)) {
            $mensagem = ['tipo' => 'success', 'texto' => 'Bloco IPv6 configurado com sucesso!'];
            $bloco_ipv6 = $bloco;
        } else {
            $mensagem = ['tipo' => 'danger', 'texto' => 'Erro ao salvar configuração. Verifique permissões.'];
        }
    } else {
        $mensagem = ['tipo' => 'warning', 'texto' => 'Formato IPv6 inválido. Use algo como: 2001:db8:1234:abcd::'];
    }
}

// Carregar bloco atual se existir
if (file_exists('/var/www/html/block_ipv6.txt')) {
    $bloco_ipv6 = trim(file_get_contents('/var/www/html/block_ipv6.txt'));
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração IPv6 - Painel Proxy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            background-image: linear-gradient(to bottom, #f1f3f8, #e9ecef);
            min-height: 100vh;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            border: none;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
        }
        .btn-primary {
            background-color: #4e73df;
            border: none;
            border-radius: 10px;
            padding: 12px 0;
            font-weight: 600;
        }
        .btn-primary:hover {
            background-color: #3a60c8;
        }
        .ipv6-example {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 10px;
            font-family: monospace;
            font-size: 0.9rem;
        }
        .logo {
            font-weight: 800;
            color: #4e73df;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10">
                <div class="card">
                    <div class="card-header bg-white border-0 pt-4">
                        <div class="text-center">
                            <h2 class="logo mb-1">PANEL PROXY</h2>
                            <h4 class="mb-0">Configuração de IPv6</h4>
                        </div>
                    </div>
                    <div class="card-body px-5 py-4">
                        <?php if (!empty($mensagem)): ?>
                            <div class="alert alert-<?= $mensagem['tipo'] ?> alert-dismissible fade show">
                                <?= $mensagem['texto'] ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <div class="mb-4">
                            <h5 class="mb-3"><i class="bi bi-router me-2"></i> Configurar Bloco IPv6</h5>
                            <p class="text-muted">Insira abaixo o bloco IPv6 /64 fornecido pelo seu provedor.</p>
                            
                            <form method="POST" class="mt-4">
                                <div class="mb-3">
                                    <label for="ipv6" class="form-label">Bloco IPv6 /64</label>
                                    <input type="text" class="form-control" id="ipv6" name="ipv6" 
                                           value="<?= htmlspecialchars($bloco_ipv6) ?>" 
                                           placeholder="Exemplo: 2001:db8:1234:abcd::" required>
                                    <div class="form-text mt-2">
                                        <small>Somente o prefixo /64 (sem a máscara no final)</small>
                                    </div>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save me-2"></i> Salvar Configuração
                                    </button>
                                </div>
                            </form>
                        </div>

                        <div class="mt-5">
                            <h5 class="mb-3"><i class="bi bi-info-circle me-2"></i> Como obter meu IPv6?</h5>
                            <div class="card border-0 bg-light">
                                <div class="card-body">
                                    <ul class="list-unstyled mb-0">
                                        <li class="mb-2"><i class="bi bi-check-circle text-success me-2"></i> Acesse o painel do seu provedor (Vultr, Contabo, Hetzner, etc.)</li>
                                        <li class="mb-2"><i class="bi bi-check-circle text-success me-2"></i> Na seção de rede, procure por "IPv6" ou "Subnets"</li>
                                        <li class="mb-2"><i class="bi bi-check-circle text-success me-2"></i> Copie o bloco no formato mostrado acima</li>
                                        <li><i class="bi bi-exclamation-triangle text-warning me-2"></i> Não inclua <code>/64</code> no final</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <?php if (!empty($bloco_ipv6)): ?>
                        <div class="mt-4">
                            <div class="alert alert-info">
                                <h6><i class="bi bi-check2-circle me-2"></i> Configuração Atual</h6>
                                <div class="ipv6-example mt-2">
                                    <?= htmlspecialchars($bloco_ipv6) ?>
                                </div>
                                <small class="d-block mt-2">Você pode gerar proxies após configurar.</small>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer bg-white border-0 text-center pb-4">
                        <small class="text-muted">Panel Proxy © <?= date('Y') ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validação básica do formulário
        document.querySelector('form').addEventListener('submit', function(e) {
            const ipv6Input = document.getElementById('ipv6');
            const ipv6Value = ipv6Input.value.trim();
            
            if (!ipv6Value.includes(':')) {
                alert('Por favor, insira um bloco IPv6 válido');
                e.preventDefault();
            }
        });
    </script>
</body>
</html>
