<?php
// Script simples para testar IPv6
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['ipv6'])) {
    $bloco = trim($_POST['ipv6']);
    file_put_contents('/var/www/html/block_ipv6.txt', $bloco);
    echo "IPv6 configurado com sucesso!";
    exit;
}
?>
<!doctype html>
<html>
<head><title>Configurar IPv6</title></head>
<body>
<form method="POST">
    Bloco IPv6: <input type="text" name="ipv6" placeholder="ex: 2001:db8:1234:abcd::">
    <button type="submit">Salvar</button>
</form>
</body>
</html>
