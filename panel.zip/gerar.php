<?php
header('Content-Type: application/json');

function execCommand($cmd) {
    return shell_exec("$cmd 2>&1");
}

try {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);

    // Variáveis
    $passwdFile = '/etc/squid/passwd';
    $squidConf  = '/etc/squid/squid.conf';
    $logDir     = '/var/www/html/logs';
    $portStart  = 30000;
    $qtd        = isset($_GET['qtd']) ? (int)$_GET['qtd'] : 10;
    $portEnd    = $portStart + $qtd - 1;
    $clearOld   = isset($_GET['clear']) && $_GET['clear'] == '1';

    // Garantir IP
    $ip4 = trim(execCommand("curl -s ifconfig.me || curl -s icanhazip.com || curl -s ipinfo.io/ip"));
    if (!filter_var($ip4, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        throw new Exception("IP inválido detectado.");
    }

    // Garantir diretórios
    if (!is_dir(dirname($passwdFile))) {
        mkdir(dirname($passwdFile), 0755, true);
    }

    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }

    // Criar passwd se não existir
    if (!file_exists($passwdFile)) {
        execCommand("touch $passwdFile");
    }

    execCommand("chown proxy:proxy $passwdFile");
    execCommand("chmod 640 $passwdFile");

    // Limpar passwd se solicitado
    if ($clearOld) {
        file_put_contents($passwdFile, '');
    }

    // Preparar usuários
    $now       = date('Ymd_His');
    $batchFile = "$logDir/proxies_$now.txt";
    $proxies   = [];
    $usedPorts = [];

    for ($i = 0; $i < $qtd; $i++) {
        $port = $portStart + $i;
        $user = 'u' . bin2hex(random_bytes(2));
        $pass = 'p' . bin2hex(random_bytes(2));
        $line = "$user:$pass@$ip4:$port";

        // Criar usuário no passwd
        $create = execCommand("htpasswd -b $passwdFile $user $pass");
        if (stripos($create, 'error') !== false || stripos($create, 'failed') !== false) {
            throw new Exception("Erro ao adicionar usuário $user: $create");
        }

        $usedPorts[] = $port;
        $proxies[] = $line;
    }

    // Abrir portas no UFW
    execCommand("ufw allow {$portStart}:{$portEnd}/tcp");

    // Atualizar squid.conf se portas não estiverem
    $squidConfContent = file_exists($squidConf) ? file_get_contents($squidConf) : '';
    foreach ($usedPorts as $port) {
        if (strpos($squidConfContent, "http_port $port") === false) {
            $squidConfContent .= "\nhttp_port $port";
        }
    }

    // Configurações básicas se não estiverem
    if (strpos($squidConfContent, 'auth_param') === false) {
        $squidConfContent = <<<CONF
auth_param basic program /usr/lib/squid/basic_ncsa_auth /etc/squid/passwd
auth_param basic realm proxy
acl authenticated proxy_auth REQUIRED
http_access allow authenticated
http_access deny all

$squidConfContent
CONF;
    }

    file_put_contents($squidConf, $squidConfContent);
    execCommand("chown proxy:proxy $squidConf");

    // Salvar proxies no .txt
    if (!file_put_contents($batchFile, implode("\n", $proxies))) {
        throw new Exception("Erro ao salvar proxies no arquivo.");
    }

    // Reiniciar Squid
    $restart = execCommand("systemctl restart squid");
    if (stripos($restart, 'error') !== false || stripos($restart, 'failed') !== false) {
        throw new Exception("Erro ao reiniciar o Squid: $restart");
    }

    // Verificar Squid
    if (trim(execCommand("pgrep squid")) === '') {
        throw new Exception("O processo do Squid não está ativo.");
    }

    echo json_encode([
        'ok' => true,
        'message' => "$qtd proxies gerados com sucesso!",
        'file' => basename($batchFile),
        'list' => implode("\n", $proxies),
        'details' => [
            'ipv4'        => $ip4,
            'ports_used'  => $usedPorts,
            'passwd_file' => $passwdFile,
            'proxy_file'  => $batchFile,
        ]
    ], JSON_UNESCAPED_SLASHES);
} catch (Exception $e) {
    echo json_encode([
        'ok'       => false,
        'error'    => $e->getMessage(),
        'solution' => 'Verifique permissões ou reinicie manualmente o Squid.',
        'trace'    => $e->getTraceAsString(),
    ], JSON_UNESCAPED_SLASHES);
}

