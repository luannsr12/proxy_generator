<?php
require_once 'security.php';

header('Content-Type: application/json');

function execCommand($cmd) {
    return shell_exec("$cmd 2>&1");
}

try {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);

    $passwdFile = '/etc/squid/passwd';
    $squidConf = '/etc/squid/squid.conf';
    $logDir = '/var/www/html/logs';

    $ip4 = trim(execCommand("curl -s ifconfig.me || curl -s icanhazip.com || curl -s ipinfo.io/ip"));
    if (!filter_var($ip4, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        throw new Exception("IP inválido.");
    }

    $portStart = 30000;
    $qtd = isset($_GET['qtd']) ? (int)$_GET['qtd'] : 10;
    $clearOld = isset($_GET['clear']) && $_GET['clear'] == '1';
    $portEnd = $portStart + $qtd - 1;

    if (!is_dir($logDir)) mkdir($logDir, 0755, true);
    if (!file_exists($passwdFile)) {
        execCommand("touch $passwdFile && chown proxy:proxy $passwdFile && chmod 640 $passwdFile");
    }

    if (!file_exists($passwdFile)) throw new Exception("Falha ao criar arquivo de senha.");

    // Limpa usuários se necessário
    if ($clearOld) {
        file_put_contents($passwdFile, '');
    }

    $squidLines = file_exists($squidConf) ? file($squidConf, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
    $newConf = [];

    // Remove linhas antigas de porta
    foreach ($squidLines as $line) {
        if (!preg_match('/^http_port\s/', trim($line))) {
            $newConf[] = $line;
        }
    }

    // Garante config de autenticação
    $authLines = [
        "auth_param basic program /usr/lib/squid/basic_ncsa_auth /etc/squid/passwd",
        "auth_param basic realm Proxy",
        "acl authenticated proxy_auth REQUIRED",
        "http_access allow authenticated",
        "http_access deny all"
    ];
    foreach ($authLines as $line) {
        if (!in_array($line, $newConf)) $newConf[] = $line;
    }

    $usedPorts = [];
    $proxies = [];

    for ($i = 0; $i < $qtd; $i++) {
        $port = $portStart + $i;
        $newConf[] = "http_port $port";
        execCommand("ufw allow $port");

        $user = 'u' . bin2hex(random_bytes(2));
        $pass = 'p' . bin2hex(random_bytes(2));

        // Nunca sobrescreve o arquivo
        $output = execCommand("htpasswd -b $passwdFile $user $pass");
        if (stripos($output, 'error') !== false || stripos($output, 'failed') !== false) {
            throw new Exception("Erro ao criar $user: $output");
        }

        $proxies[] = "$user:$pass@$ip4:$port";
        $usedPorts[] = $port;
    }

    if (!file_put_contents($squidConf, implode("\n", $newConf) . "\n")) {
        throw new Exception("Erro ao salvar squid.conf");
    }

    $now = date('Ymd_His');
    $batchFile = "$logDir/proxies_$now.txt";
    if (!file_put_contents($batchFile, implode("\n", $proxies))) {
        throw new Exception("Erro ao salvar lista de proxies.");
    }

    execCommand("chown proxy:proxy $passwdFile && chmod 640 $passwdFile");
    $restart = execCommand("sudo systemctl restart squid");
    if (stripos($restart, 'error') !== false || stripos($restart, 'failed') !== false) {
        throw new Exception("Erro ao reiniciar Squid: $restart");
    }

    echo json_encode([
        'ok' => true,
        'message' => "$qtd proxies gerados!",
        'file' => basename($batchFile),
        'list' => implode("\n", $proxies),
        'details' => [
            'ipv4' => $ip4,
            'ports_used' => $usedPorts,
            'proxy_file' => $batchFile
        ]
    ], JSON_UNESCAPED_SLASHES);

} catch (Exception $e) {
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage(),
        'timestamp' => time(),
        'solution' => 'Verifique permissões, squid.conf e passwd'
    ], JSON_UNESCAPED_SLASHES);
}

