<?php
header('Content-Type: application/json');

// Função para verificar se está rodando como root
function isRoot() {
    return posix_geteuid() === 0;
}

// Função para executar comando com sudo, se necessário
function execCommand($cmd) {
    if (!isRoot()) {
        if (!`command -v sudo`) {
            throw new Exception("Erro: 'sudo' não está instalado. Instale com 'apt-get install sudo' ou execute como root.");
        }
        $cmd = "sudo $cmd";
    }
    $output = shell_exec("$cmd 2>&1");
    return $output;
}

// Função para instalar dependências automaticamente
function instalarDependencias() {
    $commands = [
        'apt-get update',
        'apt-get install -y build-essential gcc make curl wget tar',
        'apt-get install -y net-tools iproute2',
        'cd /tmp && wget https://github.com/z3APA3A/3proxy/archive/refs/tags/0.9.4.tar.gz',
        'cd /tmp && tar xzf 0.9.4.tar.gz',
        'cd /tmp/3proxy-0.9.4 && make -f Makefile.Linux',
        'cd /tmp/3proxy-0.9.4 && make -f Makefile.Linux install',
        'mkdir -p /etc/3proxy /usr/local/etc/3proxy /var/log/3proxy',
        'touch /etc/3proxy/users.lst /etc/3proxy/3proxy.cfg',
        'chmod -R 777 /etc/3proxy /usr/local/etc/3proxy /var/log/3proxy',
        'sysctl -w net.ipv6.conf.all.disable_ipv6=0',
        'sysctl -w net.ipv6.conf.default.disable_ipv6=0',
        'echo "net.ipv6.conf.all.disable_ipv6 = 0" >> /etc/sysctl.conf',
        'echo "net.ipv6.conf.default.disable_ipv6 = 0" >> /etc/sysctl.conf',
        'sysctl -p'
    ];

    foreach ($commands as $cmd) {
        $output = execCommand($cmd);
        if (strpos($output, 'error') !== false || strpos($output, 'failed') !== false) {
            return false;
        }
    }
    return true;
}

try {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);

    // Verificar se é root, senão orientar o usuário
    if (!isRoot() && !`command -v sudo`) {
        throw new Exception("Este script precisa de permissões de administrador. Instale o 'sudo' com 'apt-get install sudo' ou execute como root.");
    }

    // Caminhos principais
    $proxyBin = '/usr/local/bin/3proxy';
    $configFile = '/etc/3proxy/3proxy.cfg';
    $usersFile = '/etc/3proxy/users.lst';
    $logDir = '/var/www/html/logs';
    $blockFile = '/var/www/html/block_ipv6.txt';
    $portStart = 30000;

    // Verificar e instalar dependências se necessário
    if (!file_exists($proxyBin)) {
        if (!instalarDependencias()) {
            throw new Exception("Falha ao instalar dependências. Execute o script de instalação manualmente: /var/www/html/install_proxy.sh");
        }
    }

    // Verificar permissões
    if (!is_writable('/etc/3proxy') || !is_writable($configFile) || !is_writable($usersFile)) {
        execCommand("chmod -R 777 /etc/3proxy /usr/local/etc/3proxy");
    }

    // Verificar configuração IPv6
    if (!file_exists($blockFile)) {
        throw new Exception("IPv6 não configurado. Acesse /ipv6.php para configurar o bloco IPv6.");
    }

    $bloco = trim(file_get_contents($blockFile));
    if (empty($bloco)) {
        throw new Exception("O arquivo de bloco IPv6 está vazio ou inválido.");
    }

    $prefix6 = explode('::', $bloco)[0];
    if (empty($prefix6)) {
        throw new Exception("Prefixo IPv6 inválido no arquivo de configuração.");
    }

    // Obter interface de rede
    $iface = trim(execCommand("ip -6 route show default | awk '{print \$5}' | head -n1"));
    if (!$iface) {
        $iface = trim(execCommand("ip -4 route show default | awk '{print \$5}' | head -n1"));
    }
    if (!$iface) $iface = 'eth0';

    // Habilitar IPv6 na interface
    execCommand("sysctl -w net.ipv6.conf.$iface.disable_ipv6=0");
    execCommand("sysctl -w net.ipv6.conf.$iface.forwarding=1");

    // Obter IP IPv4
    $ip4 = trim(execCommand("curl -4 -s ifconfig.me || curl -4 -s icanhazip.com || curl -4 -s ipinfo.io/ip"));
    if (!filter_var($ip4, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        throw new Exception("Não foi possível obter um IPv4 válido para o servidor.");
    }

    // Parâmetros
    $qtd = isset($_GET['qtd']) ? (int)$_GET['qtd'] : 10;
    $clearOld = isset($_GET['clear']) && $_GET['clear'] == '1';
    if ($qtd < 1 || $qtd > 1000) $qtd = 10;

    // Criar diretório de logs
    if (!file_exists($logDir)) {
        if (!mkdir($logDir, 0777, true)) {
            throw new Exception("Falha ao criar diretório de logs. Verifique as permissões.");
        }
    }

    $now = date('Ymd_His');
    $batchFile = "$logDir/proxies_$now.txt";

    // Limpar configurações antigas se solicitado
    if ($clearOld) {
        if (!file_put_contents($usersFile, '')) {
            execCommand("chmod 777 $usersFile");
            file_put_contents($usersFile, '');
        }
        if (!file_put_contents($configFile, '')) {
            execCommand("chmod 777 $configFile");
            file_put_contents($configFile, '');
        }
    }

    $users = [];
    $cfg = "maxconn 1000\ndaemon\nnscache 65536\ntimeouts 1 5 30 60 180 1800 15 60\n";
    $cfg .= "log /etc/3proxy/logs/3proxy.log D\nauth strong\n\n";

    $proxies = [];
    $usedPorts = [];

    // Encontrar porta inicial disponível
    for ($i = 0; $i < $qtd; $i++) {
        $port = $portStart + $i;
        while (in_array($port, $usedPorts) || is_resource(@fsockopen('127.0.0.1', $port))) {
            $port++;
        }
        $usedPorts[] = $port;

        $user = 'u' . bin2hex(random_bytes(2));
        $pass = 'p' . bin2hex(random_bytes(2));
        $ip6 = $prefix6 . '::' . dechex($i + 1);

        $users[] = "$user:CL:$pass";
        $cfg .= "allow $user\n";
        $cfg .= "proxy -6 -n -a -p$port -i$ip4 -e$ip6\n";
        
        $proxyLine = "$user:$pass@$ip4:$port";
        $proxies[] = $proxyLine;
        
        // Adicionar IPv6 à interface
        $output = execCommand("ip -6 addr add $ip6/64 dev $iface");
        if (strpos($output, 'File exists') === false && $output !== null && trim($output) !== '') {
            throw new Exception("Falha ao adicionar IPv6 $ip6: $output");
        }
    }

    // Salvar configurações
    if (!file_put_contents($usersFile, implode("\n", $users))) {
        throw new Exception("Falha ao salvar arquivo de usuários. Verifique as permissões.");
    }

    $cfg = str_replace("auth strong", "auth strong\nusers " . implode(",", $users), $cfg);
    if (!file_put_contents($configFile, $cfg)) {
        throw new Exception("Falha ao salvar arquivo de configuração do 3proxy.");
    }

    // Salvar lista de proxies
    if (!file_put_contents($batchFile, implode("\n", $proxies))) {
        throw new Exception("Falha ao salvar arquivo de proxies gerados.");
    }

    // Reiniciar 3proxy
    execCommand("pkill -9 3proxy");
    sleep(2);
    
    $output = execCommand("$proxyBin $configFile");
    if (strpos($output, 'error') !== false || strpos($output, 'failed') !== false) {
        throw new Exception("Erro ao iniciar 3proxy: " . htmlspecialchars($output));
    }

    // Verificar se está rodando
    $running = execCommand("pgrep 3proxy");
    if (empty($running)) {
        throw new Exception("3proxy não está rodando. Verifique os logs em /etc/3proxy/logs/3proxy.log");
    }

    // Retornar sucesso
    echo json_encode([
        'ok' => true,
        'file' => basename($batchFile),
        'list' => implode("\n", $proxies),
        'message' => "$qtd proxies IPv6 gerados com sucesso!",
        'details' => [
            'ipv4' => $ip4,
            'ipv6_block' => $bloco,
            'interface' => $iface,
            'ports_used' => array_slice($usedPorts, 0, $qtd),
            'config_file' => $configFile,
            'users_file' => $usersFile
        ]
    ], JSON_UNESCAPED_SLASHES);

} catch (Exception $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'ok' => false,
        'timestamp' => time(),
        'solution' => 'Tente executar manualmente: sudo php ' . $_SERVER['SCRIPT_NAME'] . ' ou use o script de instalação: /var/www/html/install_proxy.sh'
    ], JSON_UNESCAPED_SLASHES);
}
