<?php
header('Content-Type: application/json');

function execCommand($cmd) {
    return shell_exec("$cmd 2>&1");
}

try {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);

    $passwdFile = '/etc/squid/passwd';
    $logDir = '/var/www/html/logs';
    $ip4 = trim(execCommand("curl -s ifconfig.me || curl -s icanhazip.com || curl -s ipinfo.io/ip"));
    $portStart = 30000;
    $qtd = isset($_GET['qtd']) ? (int)$_GET['qtd'] : 10;
    $portEnd = $portStart + $qtd - 1;

    if (!filter_var($ip4, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        throw new Exception("Não foi possível obter um IPv4 válido para o servidor.");
    }

    // Criar diretório de logs
    if (!is_dir($logDir)) {
        if (!mkdir($logDir, 0755, true)) {
            throw new Exception("Erro ao criar diretório de logs.");
        }
    }

    // Criar o arquivo de senhas se não existir
    if (!file_exists($passwdFile)) {
        $create = execCommand("touch $passwdFile && chown proxy:proxy $passwdFile && chmod 640 $passwdFile");
        if (!file_exists($passwdFile)) {
            throw new Exception("Falha ao criar arquivo de senhas.");
        }
    }

    $now = date('Ymd_His');
    $batchFile = "$logDir/proxies_$now.txt";
    $proxies = [];
    $usedPorts = [];

    $clearOld = isset($_GET['clear']) && $_GET['clear'] == '1';
    if ($clearOld) {
        file_put_contents($passwdFile, '');
    }

    for ($i = 0; $i < $qtd; $i++) {
        $port = $portStart + $i;
        if (in_array($port, $usedPorts)) continue;

        $user = 'u' . bin2hex(random_bytes(2));
        $pass = 'p' . bin2hex(random_bytes(2));

        // Se for o primeiro, usa -c para criar o arquivo, se já existir usa normal
        $htpasswdCmd = !filesize($passwdFile) ? "htpasswd -bc" : "htpasswd -b";
        $output = execCommand("$htpasswdCmd $passwdFile $user $pass");

        if (stripos($output, 'error') !== false || stripos($output, 'failed') !== false) {
            throw new Exception("Erro ao adicionar usuário $user: $output");
        }

        $usedPorts[] = $port;
        $proxies[] = "$user:$pass@$ip4:$port";
    }

    // Ajusta permissões
    execCommand("chown proxy:proxy $passwdFile && chmod 640 $passwdFile");

    // Libera portas no firewall
    execCommand("ufw allow {$portStart}:{$portEnd}/tcp");

    // Salva a lista gerada
    if (!file_put_contents($batchFile, implode("\n", $proxies))) {
        throw new Exception("Erro ao salvar proxies no arquivo.");
    }

    // Reinicia o squid (agora com sudo sem senha)
    $restart = execCommand("sudo /bin/systemctl restart squid");
    if (stripos($restart, 'error') !== false || stripos($restart, 'failed') !== false) {
        throw new Exception("Erro ao reiniciar o Squid: $restart");
    }

    echo json_encode([
        'ok' => true,
        'message' => "$qtd proxies gerados com sucesso!",
        'file' => basename($batchFile),
        'list' => implode("\n", $proxies),
        'details' => [
            'ipv4' => $ip4,
            'ports_used' => $usedPorts,
            'users_file' => $passwdFile,
            'proxy_file' => $batchFile
        ]
    ], JSON_UNESCAPED_SLASHES);

} catch (Exception $e) {
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage(),
        'timestamp' => time(),
        'solution' => 'Execute manualmente: php ' . $_SERVER['SCRIPT_NAME']
    ], JSON_UNESCAPED_SLASHES);
}

