<?php
header('Content-Type: application/json');

function execCommand($cmd) {
    return shell_exec("$cmd 2>&1");
}

try {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);

    $passwdFile = '/etc/squid/passwd';
    $logDir = '/var/www/html/logs';
    $squidConf = '/etc/squid/squid.conf';
    $ip4 = trim(execCommand("curl -s ifconfig.me || curl -s icanhazip.com || curl -s ipinfo.io/ip"));
    $portStart = 30000;
    $qtd = isset($_GET['qtd']) ? (int)$_GET['qtd'] : 10;
    $clearOld = isset($_GET['clear']) && $_GET['clear'] == '1';
    $portEnd = $portStart + $qtd - 1;

    if (!filter_var($ip4, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        throw new Exception("IP inválido");
    }

    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }

    if (!file_exists($passwdFile)) {
        execCommand("touch $passwdFile && chown proxy:proxy $passwdFile && chmod 640 $passwdFile");
    }

    if (!file_exists($passwdFile)) {
        throw new Exception("Falha ao criar /etc/squid/passwd");
    }

    if ($clearOld) {
        file_put_contents($passwdFile, '');
    }

    $now = date('Ymd_His');
    $batchFile = "$logDir/proxies_$now.txt";
    $proxies = [];
    $usedPorts = [];

    // Garante linhas de auth e ACLs
    $authLines = [
        "auth_param basic program /usr/lib/squid/basic_ncsa_auth /etc/squid/passwd",
        "auth_param basic realm Proxy",
        "acl authenticated proxy_auth REQUIRED",
        "http_access allow authenticated",
        "http_access deny all"
    ];

    $squidLines = file_exists($squidConf) ? file($squidConf, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

    // Extrair portas já usadas
    $existingPorts = [];
    foreach ($squidLines as $line) {
        if (preg_match('/^http_port\s+(\d+)/', trim($line), $m)) {
            $existingPorts[] = (int)$m[1];
        }
    }

    // Adiciona novas portas
    for ($i = 0; $i < $qtd; $i++) {
        $port = $portStart + $i;
        if (in_array($port, $existingPorts)) continue;

        $squidLines[] = "http_port $port";
        $existingPorts[] = $port;
	
	execCommand("sudo ufw allow {$port}");

    }

    // Garante linhas de autenticação
    foreach ($authLines as $line) {
        if (!in_array($line, $squidLines)) {
            $squidLines[] = $line;
        }
    }

    file_put_contents($squidConf, implode("\n", $squidLines) . "\n");

    // Criar usuários e gerar proxies
    foreach ($existingPorts as $i => $port) {
        if ($i >= $qtd) break;

        $user = 'u' . bin2hex(random_bytes(2));
        $pass = 'p' . bin2hex(random_bytes(2));

        $htpasswdCmd = filesize($passwdFile) === 0 ? "htpasswd -bc" : "htpasswd -b";
        $output = execCommand("$htpasswdCmd $passwdFile $user $pass");

        if (stripos($output, 'error') !== false || stripos($output, 'failed') !== false) {
            throw new Exception("Erro ao adicionar usuário $user: $output");
        }

        $proxies[] = "$user:$pass@$ip4:$port";
        $usedPorts[] = $port;
    }

    execCommand("chown proxy:proxy $passwdFile && chmod 640 $passwdFile");
    
    if (!file_put_contents($batchFile, implode("\n", $proxies))) {
        throw new Exception("Erro ao salvar proxies no arquivo.");
    }

    $restart = execCommand("sudo /bin/systemctl restart squid");
    if (stripos($restart, 'error') !== false || stripos($restart, 'failed') !== false) {
        throw new Exception("Erro ao reiniciar Squid: $restart");
    }

    echo json_encode([
        'ok' => true,
        'message' => "$qtd proxies gerados!",
        'file' => basename($batchFile),
        'list' => implode("\n", $proxies),
        'details' => [
            'ipv4' => $ip4,
            'ports_used' => $usedPorts,
            'proxy_file' => $batchFile
        ]
    ], JSON_UNESCAPED_SLASHES);

} catch (Exception $e) {
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage(),
        'timestamp' => time(),
        'solution' => 'Verifique permissões, squid.conf e passwd'
    ], JSON_UNESCAPED_SLASHES);
}

