<?php
header('Content-Type: application/json');

// Executa comando shell com saída capturada
function execCommand($cmd) {
    return shell_exec("$cmd 2>&1");
}

try {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);

    // Caminhos e variáveis
    $passwdFile = '/etc/squid/passwd';
    $logDir = '/var/www/html/logs';
    $ip4 = trim(execCommand("curl -s ifconfig.me || curl -s icanhazip.com || curl -s ipinfo.io/ip"));
    $portStart = 3128;
    $portEnd = 4127;

    // Validação do IP
    if (!filter_var($ip4, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        throw new Exception("Não foi possível obter um IPv4 válido para o servidor.");
    }

    // Parâmetros
    $qtd = isset($_GET['qtd']) ? (int)$_GET['qtd'] : 10;
    $clearOld = isset($_GET['clear']) && $_GET['clear'] == '1';

    if ($qtd < 1 || $qtd > ($portEnd - $portStart + 1)) {
        $qtd = 10;
    }

    // Criar diretório de logs
    if (!is_dir($logDir) && !mkdir($logDir, 0755, true)) {
        throw new Exception("Falha ao criar diretório de logs. Verifique permissões.");
    }

    $now = date('Ymd_His');
    $batchFile = "$logDir/proxies_$now.txt";
    $proxies = [];
    $usedPorts = [];

    // Limpar usuários antigos, se solicitado
    if ($clearOld) {
        file_put_contents($passwdFile, '');
        execCommand("chmod 640 " . escapeshellarg($passwdFile));
        execCommand("chown proxy:proxy " . escapeshellarg($passwdFile));
    }

    // Gerar proxies
    for ($i = 0; $i < $qtd; $i++) {
        $port = $portStart + $i;
        if (in_array($port, $usedPorts)) continue;

        $user = 'u' . bin2hex(random_bytes(2));
        $pass = 'p' . bin2hex(random_bytes(2));

        $output = execCommand("htpasswd -b " . escapeshellarg($passwdFile) . " $user $pass");
        if (stripos($output, 'error') !== false || stripos($output, 'failed') !== false) {
            throw new Exception("Erro ao adicionar usuário $user: $output");
        }

        $usedPorts[] = $port;
        $proxies[] = "$user:$pass@$ip4:$port";
    }

    // Salvar lista
    if (!file_put_contents($batchFile, implode("\n", $proxies))) {
        throw new Exception("Erro ao salvar a lista de proxies.");
    }

    // Reiniciar Squid
    $restart = execCommand("systemctl restart squid");
    if (stripos($restart, 'error') !== false || stripos($restart, 'failed') !== false) {
        throw new Exception("Erro ao reiniciar o Squid: $restart");
    }

    // Verificar se está ativo
    $running = execCommand("pgrep squid");
    if (empty(trim($running))) {
        throw new Exception("O processo do Squid não está ativo. Verifique /var/log/squid/");
    }

    echo json_encode([
        'ok' => true,
        'message' => "$qtd proxies gerados com sucesso!",
        'file' => basename($batchFile),
        'list' => implode("\n", $proxies),
        'details' => [
            'ipv4' => $ip4,
            'ports_used' => $usedPorts,
            'users_file' => $passwdFile,
            'proxy_file' => $batchFile
        ]
    ], JSON_UNESCAPED_SLASHES);

} catch (Exception $e) {
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage(),
        'timestamp' => time(),
        'solution' => 'Tente executar manualmente: php ' . $_SERVER['SCRIPT_NAME'] . ' ou verifique o log do Squid.'
    ], JSON_UNESCAPED_SLASHES);
}

