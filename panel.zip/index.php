<?php
// No PHP changes needed, all logic is in the frontend
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Painel de Proxies Squid</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; padding-top: 30px; }
    .result-box { white-space: pre-wrap; font-family: monospace; background: #000; color: #0f0; padding: 1rem; border-radius: 5px; max-height: 400px; overflow-y: auto; }
    .success { color: #28a745; }
    .error { color: #dc3545; }
  </style>
</head>
<body>
<div class="container">
  <h1 class="mb-4 text-center">Gerador de Proxies Squid</h1>

  <form id="proxyForm" class="card p-4 shadow-sm mb-4">
    <div class="row mb-3">
      <div class="col-md-4">
        <label for="qtd" class="form-label">Quantidade</label>
        <input type="number" class="form-control" id="qtd" name="qtd" min="1" max="1000" value="10" required>
      </div>
      <div class="col-md-4 d-flex align-items-end">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="1" id="clear" name="clear">
          <label class="form-check-label" for="clear">Apagar proxies anteriores</label>
        </div>
      </div>
      <div class="col-md-4 d-flex align-items-end">
        <button type="submit" class="btn btn-primary w-100">Gerar Proxies</button>
      </div>
    </div>
  </form>

  <h5>Último lote gerado</h5>
  <div id="result" class="result-box mb-4">Nenhum proxy gerado ainda.</div>
  
  <div id="downloadSection" class="mb-4" style="display: none;">
    <a id="downloadLink" href="#" class="btn btn-success">Baixar Lista de Proxies</a>
  </div>

  <h5>Históricos de lotes</h5>
  <ul id="history" class="list-group"></ul>
</div>

<script>
  async function carregarHistorico() {
    try {
      const res = await fetch('/logs/');
      const html = await res.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');
      const links = [...doc.querySelectorAll('a')].filter(a => a.href.includes('proxies_'));
      const ul = document.getElementById('history');
      ul.innerHTML = '';
      
      links.reverse().forEach(link => {
        const li = document.createElement('li');
        li.className = 'list-group-item d-flex justify-content-between align-items-center';
        
        const linkText = document.createElement('span');
        linkText.textContent = link.textContent.replace('../logs/', '');
        
        const downloadBtn = document.createElement('a');
        downloadBtn.href = link.href;
        downloadBtn.className = 'btn btn-sm btn-outline-primary';
        downloadBtn.textContent = 'Baixar';
        downloadBtn.target = '_blank';
        
        li.appendChild(linkText);
        li.appendChild(downloadBtn);
        ul.appendChild(li);
      });
    } catch (err) {
      console.error('Erro ao carregar histórico:', err);
    }
  }

  document.getElementById('proxyForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const qtd = document.getElementById('qtd').value;
    const clear = document.getElementById('clear').checked ? '&clear=1' : '';
    const resultBox = document.getElementById('result');
    const downloadSection = document.getElementById('downloadSection');
    resultBox.textContent = 'Gerando proxies...';
    resultBox.className = 'result-box mb-4';
    downloadSection.style.display = 'none';

    try {
      const res = await fetch(`/gerar.php?qtd=${qtd}${clear}`);
      const data = await res.json();
      
      if (data.error) {
        resultBox.textContent = `ERRO: ${data.error}`;
        resultBox.className = 'result-box mb-4 error';
        if (data.details) {
          resultBox.textContent += `\n\nDetalhes:\n${JSON.stringify(data.details, null, 2)}`;
        }
      } else if (data.ok) {
        resultBox.textContent = data.list;
        resultBox.className = 'result-box mb-4 success';
        
        // Mostrar botão de download
        if (data.file) {
          const downloadLink = document.getElementById('downloadLink');
          downloadLink.href = `/logs/${data.file}`;
          downloadLink.download = data.file;
          downloadSection.style.display = 'block';
        }
        
        // Mostrar mensagem de sucesso
        if (data.message) {
          const alertDiv = document.createElement('div');
          alertDiv.className = 'alert alert-success mt-3';
          alertDiv.textContent = data.message;
          resultBox.parentNode.insertBefore(alertDiv, resultBox.nextSibling);
          
          // Remover após 5 segundos
          setTimeout(() => alertDiv.remove(), 5000);
        }
      } else {
        resultBox.textContent = 'Resposta inesperada do servidor:\n' + JSON.stringify(data, null, 2);
        resultBox.className = 'result-box mb-4 error';
      }
      
      carregarHistorico();
    } catch (err) {
      resultBox.textContent = `Erro ao processar resposta: ${err.message}`;
      resultBox.className = 'result-box mb-4 error';
      console.error('Erro:', err);
    }
  });

  window.addEventListener("DOMContentLoaded", async () => {
    carregarHistorico();
  });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
